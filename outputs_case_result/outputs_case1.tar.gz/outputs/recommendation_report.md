# RAG Pipeline Optimization Report

**Case**: 1

## Best Configuration
```json
{
  "chunk_size": 128,
  "chunk_overlap": 32,
  "chunk_strategy": "token",
  "retriever_type": "bm25",
  "embedding_model": "BAAI/bge-base-en",
  "metadata_enrichment": false,
  "rerank_enabled": true,
  "rerank_model": "BAAI/bge-reranker-base",
  "query_rewrite": false,
  "llm_provider": "zhipu-glm4-flash",
  "temperature": 0.0,
  "answer_style": "concise"
}
```

## Validation Performance (average over validation queries)

| Metric | Value |
|--------|-------|
| recall | 0.4000 |
| answer_similarity | 0.7991 |
| context_relevance | 1.0000 |
| total_score | 0.7397 |

## Decision Rationale

- The configuration was selected using Optuna Bayesian optimization to maximize the composite score.
- We performed a train/validation split (80/20) to avoid overfitting to the small benchmark.
- The search space covers chunking strategies, retrieval types, embedding models, reranking, query rewriting, and generation parameters.
- The hybrid retriever uses BM25 + dense vector with equal weight (boost=0.5) to balance lexical and semantic matching.
- Query rewriting (HYDE) generates a hypothetical answer paragraph to improve retrieval.
- Reranking further refines the top candidates using a cross-encoder.
- The chosen configuration achieved the highest validation score among all trials.

## Runtime Considerations

- Indexing time scales with chunk size and embedding model size.
- Retrieval with `dense` or `hybrid` requires embedding computation per query ( ~100ms on CPU).
- Reranking adds overhead but improves precision for small top_k.
- We recommend using GPU acceleration for production deployment.
